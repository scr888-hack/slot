# PYTHON3
SELF BOT .
------
-
 Install Self Bot :
------
 apt update
 apt upgrade
 apt install git
 apt install python3-pip
 pip3 install rsa
 pip3 install thrift==0.11.0
 pip3 install requests
 pip3 install bs4
 pip3 install gtts
 pip3 install pytz
 pip3 install humanfriendly
 pip3 install googletrans
 git clone https://github.com/BOTTUMZ/xo
 unzip xo.zip
 README.md
 y
 cd xo
 python3 xo.py


Credit By@ Hack Scan Win.
------
- `Add My ID LINE : vipscaner_win`

